# vue-starter-project

## Project setup
```
npm install
```

### Compiles and hot-reloads for development
```
npm run serve
```

### Compiles and minifies for production
```
npm run build
```

### Lints and fixes files
```
npm run lint
```

### Customize configuration
See [Configuration Reference](https://cli.vuejs.org/config/).


##App dashboards

http://localhost:8081/home  -Home page where person can request for loan
http://localhost:8081/admin- Admin approves loan, once loan request submitted

