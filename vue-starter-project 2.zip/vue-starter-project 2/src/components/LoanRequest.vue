<template>
  <div>
        <h1>Loan Request</h1>
        <div class="formfields mt-3 container">
            <div class="row mt-3">
                <label class="col-6">Loan Amount</label>
                <input type="text" v-model="loanamount" class="col-6 w-25">
            </div>
            <div class="row mt-3">
                <label class="col-6">Loan Term (in months)</label>
                <input type="text" v-model="loanterm" class="col-6 w-25" @input="getinterest">
            </div>
            <div class="row mt-3">
                <label class="col-6">Payment Frequency(in days)</label>
                <input type="text" value="7" class="col-6 w-25" disabled>
            </div>
            <div class="row mt-3">
                <label class="col-6">Interest (in percent)</label>
                <input type="text" :value="rate" class="col-6 w-25" disabled>
            </div>
            <div class="row mt-3 justify-content-center">
                <button class="btn calculatebtn" @click="calculateEmi">Calculate EMI </button>
                <div v-if="emiamount > 0" class="displayresult col-12">You have to pay Rs.{{emiamount}} weekly</div>
            </div>
            <div class="row mt-3 justify-content-center">
                <button v-b-modal.modal-1 class="btn calculatebtn" @click="requestloan">Request for Loan</button>
            </div>
            <b-modal id="modal-1" title="Submitted">
                    <p class="my-4">Loan Request Submitted for Aproval</p>
            </b-modal>
        </div>
    </div>    
</template>


<script>
import axios from 'axios'

export default {
  name: 'LoanRequest',
    
  data:function(){
      return{
        loanamount:'',
        loanterm:'',
        emiamount:0,
        rate:'',
      }
  },
  mounted:function(){
      this.getLabels();
  },
  computed:{
      
  },
  methods:{
      calculateEmi: function(){
        const interest = (this.loanamount * (this.rate * 0.01)) / this.loanterm;
        this.emiamount = ((this.loanamount / this.loanterm) + interest).toFixed(2);
      },
      getinterest:function(){
          let rate= '';
           if(this.loanterm<6){
              rate='5';
          }else if(this.loanterm<18){
              rate='7';
          }else if(this.loanterm>18){
              rate='10';
          }
          this.rate=rate;
          
      },

      requestloan:function(){

      },
      getLabels:function(){
          axios.get('../sampleresponse.json')
            .then(function (response) {
                
                console.log(response);
            })
            .catch(function (error) {
                
                console.log(error);
            })
            .then(function () {
                
            });
      }
  }
}

</script>
