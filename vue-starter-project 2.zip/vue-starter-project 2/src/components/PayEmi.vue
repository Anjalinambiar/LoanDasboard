<template>
  <div class="adminpanel">
    <div class="row mt-3 justify-content-center" v-if="approve">
        <p>Loan Approved. You can pay the EMI</p>
          <button class="btn calculatebtn" v-b-modal.modal-1 >Pay EMI</button>
                
     </div>
     <div class="row mt-3 justify-content-center" v-else>
        <p>Your loan is not approved by the Administrator. Please reach out to the admin for approval</p>
    </div>


      <b-modal id="modal-1" title="EMI Paid">
                    <p class="my-4">Success</p>
       </b-modal>
  </div>
</template>

<script>

export default {
  name: 'PayEmi',
  data:function(){
      return{
        
      }
      },
  props:{
        approve: {
        type: Boolean,
        default: false
    }
    }
  ,
  methods:{
    approveloan:function(){
     
    }
  }
}
</script>

