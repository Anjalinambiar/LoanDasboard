<template>
  <div class="adminpanel">
    <div class="row mt-3 justify-content-center">
          <button class="btn calculatebtn" @click="approveloan">Approve Loan </button>
                
     </div>
  </div>
</template>

<script>
import router from '../router'

export default {
  name: 'AdminApprove',
  data:function(){
      return{
        approve:false
      }
      },
  methods:{
    approveloan:function(){
      this.approve=true;
      router.push({
        name: 'payment',
        params: {
            approve: this.approve
        }
    });
    }
  }
}
</script>

