import Vue from "vue"
import VueRouter from "vue-router";
import AdminApprove from './components/AdminApprove.vue'
import LoanRequest from './components/LoanRequest.vue'
import PayEmi from './components/PayEmi.vue'

Vue.use(VueRouter)

export default new VueRouter({
    mode:'history',
    base:process.env.BASE_URL,
    routes:[
        {
            path:'/',  
            redirect:'/home'
        },
        {
            path:'/home',  
            name:'home',
            component: LoanRequest,
            props: true,
        },
        {
            path:'/admin',  
            component: AdminApprove,
            props: true,
        },
        {
            path:'/payment',  
            name:'payment',
            component: PayEmi,
            props: true,
        },
    ]

});