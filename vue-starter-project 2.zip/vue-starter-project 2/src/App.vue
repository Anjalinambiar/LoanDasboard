<template>
  <div id="app">
    <div class="loanrequest bodyheight">
        <div class="loanheader">Aspire</div>
        <router-view>
        </router-view>
        
        
        
      </div>
  </div>
</template>

<script>

export default {
  name: 'App',
  components: {
    
  },
  methods:{

  }
  
}
</script>


